package carcompai;

import java.io.IOException;
import java.util.List;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class SearchServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String fuelType = safe(request.getParameter("fuel_type"));
        String transmission = safe(request.getParameter("transmission"));
        String priceStr = safe(request.getParameter("max_price"));
        String sortBy = safe(request.getParameter("sort_by"));
        String suggestion = safe(request.getParameter("suggestion"));

        CarDao dao = new CarDao();
        FavouriteDAO favDao = new FavouriteDAO();   // ⭐ added
        List<Model> results;

        // ⭐ Fetch favourite count once
        int favCount = 0;
        try {
            favCount = favDao.getFavouriteCount();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        request.setAttribute("favCount", favCount);  // ⭐ send to JSP

        // ---------------- REMOVE "Any" ----------------
        if ("Any".equalsIgnoreCase(fuelType)) fuelType = null;
        if ("Any".equalsIgnoreCase(transmission)) transmission = null;

        // ---------------- CLEAN PRICE ----------------
        double maxPrice = cleanPrice(priceStr);

        /* -------- SMART SUGGESTIONS -------- */
        if (suggestion != null) {

            switch (suggestion) {

                case "budget_under_10":
                    results = dao.getCarsUnderPrice(1000000);
                    break;

                case "electric":
                    results = dao.getElectricCars();
                    break;

                case "latest":
                    results = dao.getLatestModels();
                    break;

                default:
                    results = dao.searchCars(fuelType, transmission, maxPrice, sortBy);
            }

            request.setAttribute("results", results);
            request.getRequestDispatcher("/results.jsp").forward(request, response);
            return;
        }

        /* -------- NORMAL SEARCH -------- */
        results = dao.searchCars(fuelType, transmission, maxPrice, sortBy);

        request.setAttribute("results", results);
        request.getRequestDispatcher("/results.jsp").forward(request, response);
    }

    // SAFE STRING
    private String safe(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }

    // ⭐ CLEAN PRICE LIKE "₹ 12,50,000" → 1250000
    private double cleanPrice(String s) {
        if (s == null) return -1;

        try {
            s = s.replaceAll("[^0-9]", "");  // remove ₹ , commas , spaces
            if (s.isEmpty()) return -1;
            return Double.parseDouble(s);
        } catch (Exception e) {
            return -1;
        }
    }
}
