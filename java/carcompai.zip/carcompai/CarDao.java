package carcompai;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CarDao {

    // ⭐ FINAL – CORRECT SELECT (includes top_features + official_url)
    private static final String BASE_SELECT =
        "SELECT m.model_id, b.brand_name, m.model_name, m.price, m.engine_cc, " +
        "       ft.fuel_type AS fuelTypeName, " +
        "       tt.transmission AS transmissionName, " +
        "       m.release_year, m.image_url, m.top_features, m.official_url " +
        "FROM car_model m " +
        "JOIN car_brand b ON m.brand_id = b.brand_id " +
        "JOIN fuel_type ft ON m.fuel_type_id = ft.fuel_type_id " +
        "JOIN transmission_type tt ON m.transmission_id = tt.transmission_id ";

    // ⭐ MATCHES Model.java EXACTLY
    private Model mapRow(ResultSet rs) throws Exception {
        return new Model(
            rs.getInt("model_id"),
            rs.getString("brand_name"),
            rs.getString("model_name"),
            rs.getDouble("price"),
            rs.getString("engine_cc"),
            rs.getString("fuelTypeName"),
            rs.getString("transmissionName"),
            rs.getInt("release_year"),
            rs.getString("image_url"),
            rs.getString("top_features"),   // ⭐ added
            rs.getString("official_url")    // ⭐ added
        );
    }

    // --------------------------------------------------------------------
    // MAIN SEARCH
    // --------------------------------------------------------------------
    public List<Model> searchCars(String fuelType,
                                  String transmission,
                                  double maxPrice,
                                  String sortBy) {

        List<Model> results = new ArrayList<>();

        StringBuilder sql = new StringBuilder(BASE_SELECT);
        sql.append(" WHERE 1=1 ");

        ArrayList<Object> params = new ArrayList<>();

        if (fuelType != null && !fuelType.equalsIgnoreCase("Any")) {
            sql.append(" AND ft.fuel_type = ? ");
            params.add(fuelType);
        }

        if (transmission != null && !transmission.equalsIgnoreCase("Any")) {
            sql.append(" AND tt.transmission = ? ");
            params.add(transmission);
        }

        if (maxPrice > 0) {
            sql.append(" AND m.price <= ? ");
            params.add(maxPrice);
        }

        // SORTING
        if (sortBy != null) {
            switch (sortBy) {
                case "price_asc":  sql.append(" ORDER BY m.price ASC "); break;
                case "price_desc": sql.append(" ORDER BY m.price DESC "); break;
                case "year_asc":   sql.append(" ORDER BY m.release_year ASC "); break;
                case "year_desc":  sql.append(" ORDER BY m.release_year DESC "); break;
            }
        }

        sql.append(" LIMIT 500 ");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                Object p = params.get(i);

                if (p instanceof String) ps.setString(i + 1, (String) p);
                else if (p instanceof Double) ps.setDouble(i + 1, (Double) p);
                else ps.setObject(i + 1, p);
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) results.add(mapRow(rs));
            rs.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return results;
    }

    // --------------------------------------------------------------------
    // BACKWARD COMPATIBILITY
    // --------------------------------------------------------------------
    public List<Model> searchCars(String fuelType, String transmission, double maxPrice) {
        return searchCars(fuelType, transmission, maxPrice, null);
    }

    // --------------------------------------------------------------------
    // SMART SUGGESTIONS
    // --------------------------------------------------------------------

    public List<Model> getCarsUnderPrice(double price) {
        List<Model> list = new ArrayList<>();
        String sql = BASE_SELECT + " WHERE m.price <= ? ORDER BY m.price ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, price);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
            rs.close();

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }

    public List<Model> getElectricCars() {
        List<Model> list = new ArrayList<>();
        String sql =
            BASE_SELECT +
            " WHERE ft.fuel_type IN ('Electric','Hybrid') " +
            " ORDER BY m.price ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
            rs.close();

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }

    public List<Model> getLatestModels() {
        List<Model> list = new ArrayList<>();
        String sql =
            BASE_SELECT +
            " ORDER BY m.release_year DESC, m.price DESC LIMIT 50";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
            rs.close();

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }
}
