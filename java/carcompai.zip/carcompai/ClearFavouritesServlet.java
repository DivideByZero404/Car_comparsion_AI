package carcompai;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class ClearFavouritesServlet extends HttpServlet {

    private FavouriteDAO favouriteDAO;

    @Override
    public void init() throws ServletException {
        favouriteDAO = new FavouriteDAO();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        try {
            favouriteDAO.clearFavourites();
            out.write("{\"status\":\"ok\",\"count\":0}");
        } catch (SQLException e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"status\":\"error\",\"message\":\"DB error\"}");
            e.printStackTrace();
        }
    }
}
