package carcompai;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

public class SaveCompareServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        int modelId = Integer.parseInt(req.getParameter("modelId"));

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("""
                    INSERT INTO comparisons (brand_name, model_name, price, image_url)
                    SELECT b.brand_name, m.model_name, m.price, m.image_url
                    FROM car_model m
                    JOIN car_brand b ON m.brand_id = b.brand_id
                    WHERE m.model_id = ?
            """)) {

            ps.setInt(1, modelId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

        resp.sendRedirect(req.getContextPath() + "/results.jsp");
    }
}
