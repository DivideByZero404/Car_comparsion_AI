package carcompai;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FavouriteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();

        List<String> favourites = (List<String>) session.getAttribute("favourites");
        if (favourites == null) {
            favourites = new ArrayList<>();
        }

        String modelId = req.getParameter("modelId");
        boolean remove = Boolean.parseBoolean(req.getParameter("remove"));

        // DAO instance
        FavouriteDAO favDAO = new FavouriteDAO();

        if (modelId != null) {
            int id = Integer.parseInt(modelId);

            try {
                if (remove) {
                    favourites.remove(modelId);
                    favDAO.removeFavourite(id);  // <-- FIXED
                } else {
                    if (!favourites.contains(modelId)) {
                        favourites.add(modelId);
                    }
                    favDAO.addFavourite(id);     // <-- FIXED
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        session.setAttribute("favourites", favourites);

        // Response JSON
        resp.setContentType("application/json");
        resp.getWriter().write("{\"status\":\"ok\",\"count\":" + favourites.size() + "}");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        List<String> favourites = (List<String>) session.getAttribute("favourites");

        FavouriteDAO favDAO = new FavouriteDAO();
        List<Model> favModels = new ArrayList<>();

        if (favourites != null && !favourites.isEmpty()) {
            try {
                favModels = favDAO.getFavouritesByIds(favourites);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        req.setAttribute("favourites", favModels);
        req.getRequestDispatcher("/favourites.jsp").forward(req, resp);
    }
}
