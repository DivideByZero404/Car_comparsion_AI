package carcompai;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SaveFavouriteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();

        List<String> favourites = (List<String>) session.getAttribute("favourites");
        if (favourites == null) {
            favourites = new ArrayList<>();
        }

        String modelId = req.getParameter("modelId");
        boolean remove = Boolean.parseBoolean(req.getParameter("remove"));

        if (modelId != null) {
            if (remove) {
                favourites.remove(modelId);
            } else {
                if (!favourites.contains(modelId)) {
                    favourites.add(modelId);
                }
            }
        }

        session.setAttribute("favourites", favourites);

        // Return JSON response
        resp.setContentType("application/json");
        resp.getWriter().write("{\"status\":\"ok\"}");
    }
}
