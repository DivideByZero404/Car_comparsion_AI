package carcompai;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class FavouriteServlet extends HttpServlet {

    private FavouriteDAO favDAO = new FavouriteDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();

        // Session holds ONLY model IDs
        List<String> favIds = (List<String>) session.getAttribute("favourites");
        if (favIds == null) {
            favIds = new java.util.ArrayList<>();
        }

        String modelId = req.getParameter("modelId");
        boolean remove = Boolean.parseBoolean(req.getParameter("remove"));

        if (modelId != null) {
            if (remove) {
                favIds.remove(modelId);
                favDAO.removeFavourite(Integer.parseInt(modelId));
            } else {
                if (!favIds.contains(modelId)) {
                    favIds.add(modelId);
                    favDAO.addFavourite(Integer.parseInt(modelId));
                }
            }
        }

        session.setAttribute("favourites", favIds);

        resp.setContentType("application/json");
        resp.getWriter().write("{\"status\":\"ok\",\"count\":" + favIds.size() + "}");
    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        try {
            // ✔ Fetch FULL MODEL OBJECTS
            List<Model> favModels = favDAO.getAllFavourites();

            req.setAttribute("favourites", favModels);
            req.setAttribute("favCount", favModels.size());

        } catch (Exception e) {
            throw new ServletException(e);
        }

        req.getRequestDispatcher("/favourites.jsp").forward(req, resp);
    }
}
